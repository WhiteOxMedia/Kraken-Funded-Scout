// refblock.js (Oct 12, trimmed Oct 24) — one job for the hero referral
// block: fills its 'rewards claimed today' counter from the pool's OWN
// recorded funding-ledger data (/api/kraken/rewards-today). Never
// scraped from Kraken; a failed fetch leaves the neutral placeholder
// and never blocks the page.
//
// The invite link and code are no longer share targets — the operator
// removed the four "Share on …" buttons and put each value behind its
// own <details> button, which needs no script. This file used to build
// native share intents from #refBlockLink; that block is gone with the
// buttons, so the panel's only network call is the counter below.
(function () {
  var el = document.getElementById('refBlockClaimed');
  if (!el) return;
  fetch('/api/kraken/rewards-today', { credentials: 'same-origin' })
    .then(function (r) { return r.ok ? r.json() : null; })
    .then(function (d) {
      if (!d || typeof d.rewards_claimed !== 'number') return;
      var n = d.rewards_claimed;
      if (n === 0) {
        el.textContent = '0 rewards claimed today — yours could be the first';
      } else {
        var usd = (typeof d.total_usd === 'number' ? d.total_usd : 0).toFixed(2);
        el.textContent = n + ' reward' + (n === 1 ? '' : 's') +
          ' claimed today — $' + usd + ' into the jackpot in the last 24h';
      }
    })
    .catch(function () { /* leave the placeholder line */ });
})();
